import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  url='http://localhost:8080/student-demo-1/';
  constructor(private http:HttpClient) { }
  getAllStudents()
  {
    return this.http.get(this.url+"students");
  }

  addStudent(student:any)
  {
    console.log("adding...");
    return this.http.post(this.url+"add",student);
  }
  editStudent(student:any)
  {
    console.log("adding...");
    return this.http.put(this.url+"edit",student);
  }
  
}
