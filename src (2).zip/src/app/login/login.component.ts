import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { allowedNodeEnvironmentFlags } from 'process';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:any;
  user:any;
  status:string;
  constructor(private fb:FormBuilder, private us:UserService) {
    this.loginForm=this.fb.group({
      email:[''],
      password:['']
    });
   }

  ngOnInit(): void {
  }

  fnValidate()
  {
    let email=this.loginForm.controls.email.value;
    let password=this.loginForm.controls.password.value;
    // alert(email+" : "+password);
    this.us.validateLogin(email,password).subscribe(data=>{
      console.log(data);
      this.user=data;
      if(data!=null)
       alert(this.user.role);
       else
        alert(
          'login failed'
        )
    });    
  }
  fnStatus()
  {
    this.us.getStatus().subscribe(data=>console.log(data));
  }
}
