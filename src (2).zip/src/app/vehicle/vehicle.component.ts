import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
  vehicleForm:any;
  vehicle:any;
  constructor(private vs:VehicleService, private fb:FormBuilder) { 
    this.vehicleForm=this.fb.group({
      id:[''],
      name:[''],
      type:[''],
      company:['']
    });
  }

  ngOnInit(): void {
    //this.vs.getAllVehicles().subscribe(data=>console.log(data));
    // this.vs.findVehicleById(151).subscribe(data=>console.log(data));
  }

  fnFind()
  {
    var id=this.vehicleForm.controls.id.value;
    // alert(id);
    this.vs.findVehicleById(id).subscribe(data=>{
      // alert(data);
      if(data==null)
        return;
      this.vehicle=data;      
      this.vehicleForm.patchValue(this.vehicle);
    });
  }

  fnAdd()
  {
    var vehicle=this.vehicleForm.value;
    this.vs.addVehicle(vehicle).subscribe(data=>console.log(data));
  }
  fnUpdate()
  {
    var vehicle=this.vehicleForm.value;
    this.vs.updateVehicle(vehicle).subscribe(data=>console.log(data));
  }

  fnDelete()
  {
    var id=this.vehicleForm.controls.id.value;
    this.vs.deleteVehicle(id).subscribe(data=>console.log(data));
  }
}
