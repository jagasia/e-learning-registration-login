import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userForm:any;
  constructor(private fb: FormBuilder, private us:UserService) {
    this.userForm=this.fb.group({
      email:[''],
      firstName:[''],
      lastName:[''],
      password:[''],
      cpassword:[''],      
      mobile:[''],
      interests:[''],
      qualification:[''],
      role:['']      
    });
   }

  ngOnInit(): void {
  }

  fnAdd()
  {
    var user:any;
    user=this.userForm.value;
    alert(JSON.stringify(user));
    this.us.fnAddUser(user).subscribe(data=>console.log(data));
  }
}
