import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url:string='http://localhost:8080/user/';
  constructor(private http:HttpClient) { }

  fnAddUser(user:any)
  {
    console.log(JSON.stringify(user));
    return this.http.post(this.url,user);
  }

  validateLogin(email:string, password:string)
  {
    return this.http.get(this.url+email+"/"+password);
  }

  getStatus()
  {
    return this.http.get(this.url+"dummy");
  }
}
